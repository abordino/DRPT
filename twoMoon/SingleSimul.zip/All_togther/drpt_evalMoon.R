rm(list = ls())  # Clear environment
gc()             # Free memory

library(MASS)
library(latex2exp)
library(DRPT)
library(kerTests)
library(reticulate)

budgets = c(2^4, 2^7, 2^9, 2^12, 2^15)
methods = c("bnre", "nre")  

reps = 300


# ---- reload & plot two lines with ±1 SD error bars: BNRE vs NRE over N_train ----
suppressPackageStartupMessages({ library(ggplot2) })

# check if result are consistent
# Explicit (clear and simple)
all_trials_1 = utils::read.csv("results/drpt_trials_1.csv", header = FALSE)
all_trials_2 = utils::read.csv("results/drpt_trials_2.csv", header = FALSE)
all_trials_3 = utils::read.csv("results/drpt_trials_3.csv", header = FALSE)

all_trials_123 = rbind(all_trials_1, all_trials_2, all_trials_3)

all_res = list()
for (B in budgets) {
  for (m in methods) {
      rejs = all_trials[tolower(all_trials$V1) == m & all_trials$V2 == B, ]$V5
      # Per-(method,budget) summaries with SDs
      all_res[[length(all_res) + 1]] = data.frame(
        method = toupper(m),
        budget = B,
        power  = mean(rejs,  na.rm = TRUE),                 # mean of 0/1 = power
        sd_rej = sqrt(mean(rejs,  na.rm = TRUE)*(1-mean(rejs,  na.rm = TRUE))/reps)         # SD of 0/1 sequence
      )
  }
}

summary_df = do.call(rbind, all_res)
utils::write.csv(summary_df, file = "results/drpt_summary.csv", row.names = FALSE)


summary_df = utils::read.csv("results/drpt_summary.csv")

# clamp error bars to [0,1] ranges where appropriate
summary_df$power_lo = pmax(0, summary_df$power - summary_df$sd_rej)
summary_df$power_hi = pmin(1, summary_df$power + summary_df$sd_rej)

# dodge so methods at the same budget don't sit exactly on top of each other
pos = ggplot2::position_dodge(width = 0.08)

p_power = ggplot2::ggplot(
  summary_df,
  ggplot2::aes(x = budget, y = power, color = method, group = method)
) +
  ggplot2::geom_line(position = pos, linewidth = 1) +
  ggplot2::geom_point(
    ggplot2::aes(shape = method),
    size = 2.7,
    position = pos,
    stroke = 0.6
  ) +
  ggplot2::geom_errorbar(
    ggplot2::aes(ymin = power_lo, ymax = power_hi),
    width = 0.02,           # skinny caps
    linewidth = 0.5,
    position = pos
  ) +
  scale_x_log10(
    breaks = budgets,
    labels = c("16",  "128",  "512",  "4096", "32768")
  ) +
  ggplot2::coord_cartesian(ylim = c(0, 1), expand = FALSE) +
  ggplot2::labs(
    x = "N_train",
    y = "Power",
    color = "Method",
    shape = "Method"
  ) +
  # colorblind-friendly palette
  viridis::scale_color_viridis(discrete = TRUE, end = 0.9) +
  # clean theme: no grid, crisp axes
  ggplot2::theme_classic(base_size = 13) +
  ggplot2::theme(
    legend.position = "top",
    legend.title = ggplot2::element_text(face = "bold"),
    axis.title = ggplot2::element_text(face = "bold"),
    axis.ticks.length = grid::unit(2.5, "pt"),
    plot.caption = ggplot2::element_text(hjust = 1, margin = ggplot2::margin(t = 6))
  ) +
  ggplot2::guides(
    color = ggplot2::guide_legend(override.aes = list(linewidth = 1.2, size = 3)),
    shape = ggplot2::guide_legend(override.aes = list(size = 3))
  )

print(p_power)

# make the plotting panel square
p_power = p_power + ggplot2::theme(aspect.ratio = 1)

# choose one size for both outputs
fig_size_in = 6  # inches

ggplot2::ggsave(
  "results/drpt_power_vs_budget.png",
  p_power,
  width = fig_size_in, height = fig_size_in, units = "in", dpi = 300
)

ggplot2::ggsave(
  "results/drpt_power_vs_budget.pdf",
  p_power,
  width = fig_size_in, height = fig_size_in, units = "in",
  device = cairo_pdf, useDingbats = FALSE
)

cat("Saved:\n",
    "- raw replicate results to results/drpt_trials.csv\n",
    "- summary to results/drpt_summary.csv\n",
    "- plots to results/ (PNG + PDF)\n")



library(magick)

paths = c("results/drpt_power_vs_budget.png", "results/roc_curves.png")
imgs  = image_read(paths)

# Pick a target height (use the smaller one to avoid upscaling artifacts)
target_h = min(image_info(imgs)$height)

# Scale each image to that exact height, preserving aspect ratio
imgs_same_h = image_scale(imgs, paste0("x", target_h))

# Now they share the same height; append side-by-side
combo = image_append(imgs_same_h, stack = FALSE)
image_write(combo, "results/combined_3.png")